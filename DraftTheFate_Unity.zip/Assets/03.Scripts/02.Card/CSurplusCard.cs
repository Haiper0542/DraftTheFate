﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CSurplusCard: CursedCard {

    public override bool UseSkill()
    {
        return false;
    }
}
