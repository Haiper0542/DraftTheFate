﻿public class CursedCard : Card
{
    public override bool UseSkill()
    {
        return false;
    }
}
